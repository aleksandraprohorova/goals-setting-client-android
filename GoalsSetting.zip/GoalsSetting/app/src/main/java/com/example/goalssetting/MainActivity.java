package com.example.goalssetting;

import androidx.appcompat.app.AlertController;
import androidx.appcompat.app.AppCompatActivity;

import android.app.DatePickerDialog;
import android.os.Bundle;
import android.text.format.DateUtils;
import android.view.View;
import android.widget.Button;
import android.widget.DatePicker;
import android.widget.EditText;


import java.util.Calendar;
import java.util.concurrent.TimeUnit;

public class MainActivity extends AppCompatActivity {

    Calendar startDate = Calendar.getInstance();
    Calendar endDate = Calendar.getInstance();
    Button viewStartDate;
    Button viewEndDate;
    EditText sprintTime;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        viewStartDate = findViewById(R.id.startTime);
        viewEndDate = findViewById(R.id.endTime);

        sprintTime = findViewById(R.id.sprintTime);
        sprintTime.setEnabled(false);



        setInitialDateTime();



    }

    public void setStartDate(View v) {
        new DatePickerDialog(MainActivity.this, startDateSetListener,
                startDate.get(Calendar.YEAR),
                startDate.get(Calendar.MONTH),
                startDate.get(Calendar.DAY_OF_MONTH))
                .show();
    }
    public void setEndDate(View v) {
        new DatePickerDialog(MainActivity.this, endDateSetListener,
                endDate.get(Calendar.YEAR),
                endDate.get(Calendar.MONTH),
                endDate.get(Calendar.DAY_OF_MONTH))
                .show();
    }

    DatePickerDialog.OnDateSetListener startDateSetListener=new DatePickerDialog.OnDateSetListener() {
        public void onDateSet(DatePicker view, int year, int monthOfYear, int dayOfMonth) {
            startDate.set(Calendar.YEAR, year);
            startDate.set(Calendar.MONTH, monthOfYear);
            startDate.set(Calendar.DAY_OF_MONTH, dayOfMonth);
            setInitialDateTime();
        }
    };
    DatePickerDialog.OnDateSetListener endDateSetListener=new DatePickerDialog.OnDateSetListener() {
        public void onDateSet(DatePicker view, int year, int monthOfYear, int dayOfMonth) {
            endDate.set(Calendar.YEAR, year);
            endDate.set(Calendar.MONTH, monthOfYear);
            endDate.set(Calendar.DAY_OF_MONTH, dayOfMonth);
            setInitialDateTime();
        }
    };
    private void setInitialDateTime() {

        viewStartDate.setText(DateUtils.formatDateTime(this,
                startDate.getTimeInMillis(),
                DateUtils.FORMAT_SHOW_DATE | DateUtils.FORMAT_SHOW_YEAR));

        viewEndDate.setText(DateUtils.formatDateTime(this,
                endDate.getTimeInMillis(),
                DateUtils.FORMAT_SHOW_DATE | DateUtils.FORMAT_SHOW_YEAR));

        long diff = endDate.getTimeInMillis() - startDate.getTimeInMillis();


        sprintTime.setText(String.format("%s days", String.valueOf(TimeUnit.DAYS.convert(diff, TimeUnit.MILLISECONDS))));
    }
}
